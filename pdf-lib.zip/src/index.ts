import { createPdf } from "./pdf-lib";


createPdf()